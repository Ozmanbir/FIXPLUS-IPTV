# FIXPLUS IPTV

Android telefon ve Android TV/TV Box için basit M3U/M3U_PLUS IPTV oynatıcı.

- M3U_PLUS listesini uygulama açılışında indirir.
- Grup ve kanal adlarını listeler.
- Arama desteği vardır.
- Media3/ExoPlayer ile yayın oynatır.
- HTTP ve HTTPS bağlantıları için yapılandırılmıştır.
- GitHub Actions ile Android Studio olmadan APK üretir.

## APK oluşturma

GitHub'da **Eylemler (Actions)** sekmesine girip **FIXPLUS IPTV APK** iş akışını çalıştırın.
Derleme tamamlanınca `FIXPLUS-IPTV-APK` adlı artifact içinden APK alın.

> Not: Oynatma listesindeki kullanıcı adı/şifre APK içine gömülüdür. Depoyu herkese açık bırakmayın.
