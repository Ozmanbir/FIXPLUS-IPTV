plugins {
    id("com.android.application")
}

android {
    namespace = "com.fixplus.iptv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fixplus.iptv"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.8.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.8.1")
    implementation("androidx.media3:media3-ui:1.8.1")
}
