package com.fixplus.iptv;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    // Kullanıcının istediği sabit M3U bağlantısı.
    // Not: Bu URL kullanıcı adı/şifre içerdiği için APK'yı paylaşırken dikkat edin.
    private static final String PLAYLIST_URL =
            "http://buluqhd.shop:8080/get.php?username=erdal.7177&password=fa8c2c539a12d535&type=m3u_plus";

    private final ArrayList<Channel> allChannels = new ArrayList<>();
    private final ArrayList<Channel> shownChannels = new ArrayList<>();
    private ArrayAdapter<Channel> adapter;
    private ListView listView;
    private EditText search;
    private TextView status;
    private PlayerView playerView;
    private ExoPlayer player;
    private ExecutorService executor;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        executor = Executors.newSingleThreadExecutor();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(10, 10, 10));

        TextView title = new TextView(this);
        title.setText("FIXPLUS IPTV");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(18, 8, 18, 8);
        title.setBackgroundColor(Color.rgb(20, 20, 20));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        root.addView(playerView, new LinearLayout.LayoutParams(
                -1, dp(260)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(8, 8, 8, 8);

        search = new EditText(this);
        search.setHint("Kanal ara...");
        search.setSingleLine(true);
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setPadding(14, 0, 14, 0);
        controls.addView(search, new LinearLayout.LayoutParams(0, dp(48), 1f));

        Button reload = new Button(this);
        reload.setText("Yenile");
        controls.addView(reload, new LinearLayout.LayoutParams(dp(90), dp(48)));
        root.addView(controls);

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setPadding(14, 4, 14, 8);
        status.setText("Liste yükleniyor...");
        root.addView(status);

        listView = new ListView(this);
        listView.setBackgroundColor(Color.rgb(14, 14, 14));
        adapter = new ArrayAdapter<Channel>(this,
                android.R.layout.simple_list_item_1, shownChannels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convertView, parent);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(16);
                tv.setPadding(20, 16, 20, 16);
                return tv;
            }
        };
        listView.setAdapter(adapter);
        root.addView(listView, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);

        reload.setOnClickListener(v -> loadPlaylist());
        listView.setOnItemClickListener((parent, view, position, id) -> play(shownChannels.get(position)));

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) {
                filter(s.toString());
            }
            public void afterTextChanged(android.text.Editable e) {}
        });

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        loadPlaylist();
    }

    private void loadPlaylist() {
        status.setText("M3U listesi indiriliyor...");
        executor.submit(() -> {
            try {
                ArrayList<Channel> parsed = parseM3U(PLAYLIST_URL);
                mainHandler.post(() -> {
                    allChannels.clear();
                    allChannels.addAll(parsed);
                    filter(search.getText().toString());
                    status.setText(allChannels.size() + " kanal yüklendi");
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        status.setText("Liste yüklenemedi: " + e.getMessage()));
            }
        });
    }

    private ArrayList<Channel> parseM3U(String address) throws Exception {
        ArrayList<Channel> result = new ArrayList<>();
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", "FIXPLUS-IPTV/1.0");
        c.setRequestProperty("Accept", "*/*");
        c.setInstanceFollowRedirects(true);

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(c.getInputStream(), "UTF-8"))) {

            String line;
            String info = null;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                if (line.startsWith("#EXTINF")) {
                    info = line;
                } else if (!line.startsWith("#") && info != null) {
                    String name = extractName(info);
                    String group = extractAttribute(info, "group-title");
                    result.add(new Channel(name, group, line));
                    info = null;
                }
            }
        } finally {
            c.disconnect();
        }
        return result;
    }

    private String extractName(String extinf) {
        int comma = extinf.indexOf(',');
        if (comma >= 0 && comma + 1 < extinf.length())
            return extinf.substring(comma + 1).trim();
        return "Bilinmeyen kanal";
    }

    private String extractAttribute(String line, String key) {
        String needle = key + "=\"";
        int start = line.indexOf(needle);
        if (start < 0) return "";
        start += needle.length();
        int end = line.indexOf('"', start);
        if (end < 0) return "";
        return line.substring(start, end);
    }

    private void filter(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();
        shownChannels.clear();
        for (Channel ch : allChannels) {
            if (q.isEmpty()
                    || ch.name.toLowerCase().contains(q)
                    || ch.group.toLowerCase().contains(q)) {
                shownChannels.add(ch);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void play(Channel ch) {
        status.setText("Açılıyor: " + ch.name);
        Uri uri = Uri.parse(ch.url);

        MediaItem.Builder item = new MediaItem.Builder().setUri(uri);
        String lower = ch.url.toLowerCase();
        if (lower.contains(".m3u8")) {
            item.setMimeType(MimeTypes.APPLICATION_M3U8);
        }

        player.setMediaItem(item.build());
        player.prepare();
        player.play();
        status.setText(ch.name + (ch.group.isEmpty() ? "" : "  •  " + ch.group));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (player != null) player.release();
        if (executor != null) executor.shutdownNow();
        super.onDestroy();
    }

    public static class Channel {
        final String name;
        final String group;
        final String url;

        Channel(String name, String group, String url) {
            this.name = name;
            this.group = group;
            this.url = url;
        }

        @Override
        public String toString() {
            return group == null || group.isEmpty() ? name : name + "  •  " + group;
        }
    }
}
